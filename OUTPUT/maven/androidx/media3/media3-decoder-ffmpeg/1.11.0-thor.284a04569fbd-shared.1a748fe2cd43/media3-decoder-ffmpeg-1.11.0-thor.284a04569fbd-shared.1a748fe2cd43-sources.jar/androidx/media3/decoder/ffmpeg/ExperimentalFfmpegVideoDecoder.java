package androidx.media3.decoder.ffmpeg;

import static androidx.annotation.VisibleForTesting.PACKAGE_PRIVATE;

import android.view.Surface;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.util.Assertions;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.SimpleDecoder;
import androidx.media3.decoder.VideoDecoderOutputBuffer;

import java.nio.ByteBuffer;
import java.util.List;

/**
 * Ffmpeg Video decoder.
 */
@VisibleForTesting(otherwise = PACKAGE_PRIVATE)
@UnstableApi
/* package */ final class ExperimentalFfmpegVideoDecoder
    extends SimpleDecoder<DecoderInputBuffer, VideoDecoderOutputBuffer, FfmpegDecoderException> {

  private static final String TAG = "FfmpegVideoDecoder";

  // LINT.IfChange
  private static final int VIDEO_DECODER_SUCCESS = 0;
  private static final int VIDEO_DECODER_ERROR_INVALID_DATA = -1;
  private static final int VIDEO_DECODER_ERROR_OTHER = -2;
  private static final int VIDEO_DECODER_ERROR_TRY_AGAIN = -3;
  private static final int VIDEO_DECODER_ERROR_SURFACE = -4;
  private static final int VIDEO_DECODER_END_OF_STREAM = -5;
  // LINT.ThenChange(../../../../../../../jni/ffmpeg_jni.cc)

  private final String codecName;
  private final Object nativeContextLock;
  private long nativeContext;
  @Nullable
  private final byte[] extraData;
  private Format outputFormat;
  private boolean draining;
  @C.VideoOutputMode
  private volatile int outputMode;

  private int degree = 0;

  /**
   * Creates a Ffmpeg video Decoder.
   *
   * @param numInputBuffers        Number of input buffers.
   * @param numOutputBuffers       Number of output buffers.
   * @param initialInputBufferSize The initial size of each input buffer, in bytes.
   * @param threads                Number of threads libffmpeg will use to decode.
   * @throws FfmpegDecoderException Thrown if an exception occurs when initializing the decoder.
   */
  public ExperimentalFfmpegVideoDecoder(
      int numInputBuffers, int numOutputBuffers, int initialInputBufferSize, int threads,
      Format format)
      throws FfmpegDecoderException {
    super(
        new DecoderInputBuffer[numInputBuffers],
        new VideoDecoderOutputBuffer[numOutputBuffers]);
    if (!FfmpegLibrary.isAvailable()) {
      throw new FfmpegDecoderException("Failed to load decoder native library.");
    }
    nativeContextLock = new Object();
    codecName = Assertions.checkNotNull(FfmpegLibrary.getCodecName(format));
    extraData = getExtraData(format.sampleMimeType, format.initializationData);
    outputFormat = getDecodedOutputFormat(format);
    degree = format.rotationDegrees;
    nativeContext = ffmpegInitialize(codecName, extraData, threads, degree);
    if (nativeContext == 0) {
      throw new FfmpegDecoderException("Failed to initialize decoder.");
    }
    setInitialInputBufferSize(initialInputBufferSize);
  }

  /**
   * Returns FFmpeg-compatible codec-specific initialization data ("extra data"), or {@code null} if
   * not required.
   */
  @Nullable
  private static byte[] getExtraData(String mimeType, List<byte[]> initializationData) {
    int size = 0;
    for (int i = 0; i < initializationData.size(); i++) {
      size += initializationData.get(i).length;
    }
    if (size > 0) {
      byte[] extra = new byte[size];
      ByteBuffer wrapper = ByteBuffer.wrap(extra);
      for (int i = 0; i < initializationData.size(); i++) {
        wrapper.put(initializationData.get(i));
      }
      return extra;
    }
    return null;
  }

  static Format getDecodedOutputFormat(Format format) {
    if (format.rotationDegrees == 0) {
      return format;
    }
    Format.Builder outputFormat = format.buildUpon().setRotationDegrees(0);
    if (format.rotationDegrees == 90 || format.rotationDegrees == 270) {
      outputFormat.setPixelWidthHeightRatio(1f / format.pixelWidthHeightRatio);
    }
    return outputFormat.build();
  }

  @Override
  public String getName() {
    return "ffmpeg" + FfmpegLibrary.getVersion() + "-" + codecName;
  }

  /**
   * Sets the output mode for frames rendered by the decoder.
   *
   * @param outputMode The output mode.
   */
  public void setOutputMode(@C.VideoOutputMode int outputMode) {
    this.outputMode = outputMode;
  }

  @Override
  protected DecoderInputBuffer createInputBuffer() {
    return new DecoderInputBuffer(
        DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_DIRECT,
        FfmpegLibrary.getInputBufferPaddingSize());
  }

  @Override
  protected VideoDecoderOutputBuffer createOutputBuffer() {
    return new VideoDecoderOutputBuffer(this::releaseOutputBuffer);
  }

  @Override
  protected void releaseOutputBuffer(VideoDecoderOutputBuffer outputBuffer) {
    synchronized (nativeContextLock) {
      long frameHandle = outputBuffer.decoderPrivate;
      if (frameHandle != 0) {
        outputBuffer.decoderPrivate = 0;
        if (nativeContext != 0) {
          ffmpegReleaseFrame(nativeContext, frameHandle);
        }
      }
    }
    super.releaseOutputBuffer(outputBuffer);
  }

  @Override
  @Nullable
  protected FfmpegDecoderException decode(
      DecoderInputBuffer inputBuffer, VideoDecoderOutputBuffer outputBuffer, boolean reset) {
    if (reset) {
      nativeContext = ffmpegReset(nativeContext);
      if (nativeContext == 0) {
        return new FfmpegDecoderException("Error resetting (see logcat).");
      }
      draining = false;
    }

    ByteBuffer inputData = Util.castNonNull(inputBuffer.data);
    int inputSize = inputData.limit();
    if (inputBuffer.format != null) {
      outputFormat = getDecodedOutputFormat(inputBuffer.format);
    }
    int sendPacketResult =
        ffmpegSendPacket(nativeContext, inputData, inputSize, inputBuffer.timeUs);

    if (sendPacketResult == VIDEO_DECODER_ERROR_INVALID_DATA) {
      outputBuffer.shouldBeSkipped = true;
      return null;
    } else if (sendPacketResult == VIDEO_DECODER_ERROR_OTHER) {
      return new FfmpegDecoderException("ffmpegDecode error: (see logcat)");
    } else if (sendPacketResult == VIDEO_DECODER_END_OF_STREAM) {
      return new FfmpegDecoderException("Unexpected end of stream while sending a packet.");
    }

    @C.VideoOutputMode int currentOutputMode = outputMode;
    boolean decodeOnly = !isAtLeastOutputStartTimeUs(inputBuffer.timeUs);
    if (!decodeOnly) {
      outputBuffer.init(inputBuffer.timeUs, currentOutputMode, null);
    }
    int receiveFrameResult =
        ffmpegReceiveFrame(nativeContext, currentOutputMode, outputBuffer, decodeOnly);
    if (receiveFrameResult == VIDEO_DECODER_ERROR_OTHER
        || receiveFrameResult == VIDEO_DECODER_END_OF_STREAM
        || (sendPacketResult == VIDEO_DECODER_ERROR_TRY_AGAIN
            && receiveFrameResult == VIDEO_DECODER_ERROR_TRY_AGAIN)) {
      return new FfmpegDecoderException("ffmpegDecode error: (see logcat)");
    }

    if (sendPacketResult == VIDEO_DECODER_ERROR_TRY_AGAIN) {
      setInputBufferNotConsumed();
    }
    if (receiveFrameResult == VIDEO_DECODER_ERROR_INVALID_DATA
        || receiveFrameResult == VIDEO_DECODER_ERROR_TRY_AGAIN) {
      outputBuffer.shouldBeSkipped = true;
      return null;
    }

    outputBuffer.format = outputFormat;
    outputBuffer.shouldBeSkipped = !isAtLeastOutputStartTimeUs(outputBuffer.timeUs);

    return null;
  }

  @Override
  @Nullable
  protected FfmpegDecoderException decodeEndOfStream(
      VideoDecoderOutputBuffer outputBuffer, boolean reset) {
    if (reset) {
      nativeContext = ffmpegReset(nativeContext);
      if (nativeContext == 0) {
        return new FfmpegDecoderException("Error resetting (see logcat).");
      }
      draining = false;
    }
    if (!draining) {
      int sendPacketResult =
          ffmpegSendPacket(
              nativeContext, /* encodedData= */ null, /* length= */ 0, C.TIME_UNSET);
      if (sendPacketResult == VIDEO_DECODER_SUCCESS) {
        draining = true;
      } else if (sendPacketResult == VIDEO_DECODER_END_OF_STREAM) {
        outputBuffer.addFlag(C.BUFFER_FLAG_END_OF_STREAM);
        return null;
      } else if (sendPacketResult != VIDEO_DECODER_ERROR_TRY_AGAIN) {
        return new FfmpegDecoderException("Error flushing FFmpeg decoder (see logcat).");
      }
    }

    @C.VideoOutputMode int currentOutputMode = outputMode;
    outputBuffer.init(C.TIME_UNSET, currentOutputMode, null);
    int receiveFrameResult =
        ffmpegReceiveFrame(
            nativeContext, currentOutputMode, outputBuffer, /* decodeOnly= */ false);
    if (receiveFrameResult == VIDEO_DECODER_SUCCESS) {
      outputBuffer.format = outputFormat;
      outputBuffer.shouldBeSkipped = !isAtLeastOutputStartTimeUs(outputBuffer.timeUs);
      return null;
    } else if (receiveFrameResult == VIDEO_DECODER_END_OF_STREAM) {
      draining = false;
      outputBuffer.addFlag(C.BUFFER_FLAG_END_OF_STREAM);
      return null;
    }
    return new FfmpegDecoderException("Error draining FFmpeg decoder (see logcat).");
  }

  @Override
  protected FfmpegDecoderException createUnexpectedDecodeException(Throwable error) {
    return new FfmpegDecoderException("Unexpected decode error", error);
  }

  @Override
  public void release() {
    super.release();
    synchronized (nativeContextLock) {
      if (nativeContext != 0) {
        ffmpegRelease(nativeContext);
        nativeContext = 0;
      }
    }
  }

  /**
   * Renders output buffer to the given surface. Must only be called when in {@link
   * C#VIDEO_OUTPUT_MODE_SURFACE_YUV} mode.
   *
   * @param outputBuffer Output buffer.
   * @param surface      Output surface.
   * @throws FfmpegDecoderException Thrown if the decoder state is invalid.
   */
  public void renderToSurface(VideoDecoderOutputBuffer outputBuffer, Surface surface)
      throws FfmpegDecoderException {
    if (outputBuffer.mode != C.VIDEO_OUTPUT_MODE_SURFACE_YUV) {
      throw new FfmpegDecoderException("Invalid output mode.");
    }
    if (!surface.isValid()) {
      return;
    }
    synchronized (nativeContextLock) {
      if (nativeContext == 0) {
        throw new FfmpegDecoderException("Decoder is released.");
      }
      int result =
          ffmpegRenderFrame(
              nativeContext,
              surface,
              outputBuffer,
              outputBuffer.width,
              outputBuffer.height);
      if (result != VIDEO_DECODER_SUCCESS && result != VIDEO_DECODER_ERROR_SURFACE) {
        throw new FfmpegDecoderException("Buffer render failed with error code " + result + ".");
      }
    }
  }

  private native long ffmpegInitialize(String codecName, @Nullable byte[] extraData, int threads,
      int degree);

  private native long ffmpegReset(long context);

  private native void ffmpegRelease(long context);

  private native void ffmpegReleaseFrame(long context, long frameHandle);

  private native int ffmpegRenderFrame(
      long context, Surface surface, VideoDecoderOutputBuffer outputBuffer,
      int displayedWidth,
      int displayedHeight);

  /**
   * Decodes the encoded data passed.
   *
   * @param context     Decoder context.
   * @param encodedData Encoded data.
   * @param length      Length of the data buffer.
   * @return {@link #VIDEO_DECODER_SUCCESS} if successful, {@link #VIDEO_DECODER_ERROR_OTHER} if an
   * error occurred.
   */
  private native int ffmpegSendPacket(long context, @Nullable ByteBuffer encodedData, int length,
      long inputTime);

  /**
   * Gets the decoded frame.
   *
   * @param context      Decoder context.
   * @param outputBuffer Output buffer for the decoded frame.
   * @return {@link #VIDEO_DECODER_SUCCESS} if successful, {@link #VIDEO_DECODER_ERROR_INVALID_DATA}
   * if successful but the frame is decode-only, {@link #VIDEO_DECODER_ERROR_OTHER} if an error
   * occurred.
   */
  private native int ffmpegReceiveFrame(
      long context, int outputMode, VideoDecoderOutputBuffer outputBuffer, boolean decodeOnly);

}
