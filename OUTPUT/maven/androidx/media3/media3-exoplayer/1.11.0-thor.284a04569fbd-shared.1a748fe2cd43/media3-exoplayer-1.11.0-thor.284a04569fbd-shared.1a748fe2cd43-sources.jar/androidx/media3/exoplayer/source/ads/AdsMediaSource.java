/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.exoplayer.source.ads;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.annotation.ElementType.TYPE_USE;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import androidx.annotation.IntDef;
import androidx.annotation.Nullable;
import androidx.media3.common.AdPlaybackState;
import androidx.media3.common.AdPlaybackState.AdGroup;
import androidx.media3.common.AdViewProvider;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Timeline;
import androidx.media3.common.util.NullableType;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.TransferListener;
import androidx.media3.exoplayer.source.ClippingMediaPeriod;
import androidx.media3.exoplayer.source.CompositeMediaSource;
import androidx.media3.exoplayer.source.LoadEventInfo;
import androidx.media3.exoplayer.source.MaskingMediaPeriod;
import androidx.media3.exoplayer.source.MaskingMediaSource;
import androidx.media3.exoplayer.source.MediaLoadData;
import androidx.media3.exoplayer.source.MediaPeriod;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId;
import androidx.media3.exoplayer.source.MediaSourceEventListener;
import androidx.media3.exoplayer.upstream.Allocator;
import java.io.IOException;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;

/**
 * A {@link MediaSource} that inserts ads linearly into a provided content media source.
 *
 * <p>The wrapped content media source must contain a single {@link Timeline.Period}.
 */
@UnstableApi
public final class AdsMediaSource extends CompositeMediaSource<MediaPeriodId> {

  /**
   * Wrapper for exceptions that occur while loading ads, which are notified via {@link
   * MediaSourceEventListener#onLoadError(int, MediaPeriodId, LoadEventInfo, MediaLoadData,
   * IOException, boolean)}.
   */
  public static final class AdLoadException extends IOException {

    /**
     * Types of ad load exceptions. One of {@link #TYPE_AD}, {@link #TYPE_AD_GROUP}, {@link
     * #TYPE_ALL_ADS} or {@link #TYPE_UNEXPECTED}.
     */
    @Documented
    @Retention(RetentionPolicy.SOURCE)
    @Target(TYPE_USE)
    @IntDef({TYPE_AD, TYPE_AD_GROUP, TYPE_ALL_ADS, TYPE_UNEXPECTED})
    public @interface Type {}

    /** Type for when an ad failed to load. The ad will be skipped. */
    public static final int TYPE_AD = 0;

    /** Type for when an ad group failed to load. The ad group will be skipped. */
    public static final int TYPE_AD_GROUP = 1;

    /** Type for when all ad groups failed to load. All ads will be skipped. */
    public static final int TYPE_ALL_ADS = 2;

    /** Type for when an unexpected error occurred while loading ads. All ads will be skipped. */
    public static final int TYPE_UNEXPECTED = 3;

    /** Returns a new ad load exception of {@link #TYPE_AD}. */
    public static AdLoadException createForAd(Exception error) {
      return new AdLoadException(TYPE_AD, error);
    }

    /** Returns a new ad load exception of {@link #TYPE_AD_GROUP}. */
    public static AdLoadException createForAdGroup(Exception error, int adGroupIndex) {
      return new AdLoadException(
          TYPE_AD_GROUP, new IOException("Failed to load ad group " + adGroupIndex, error));
    }

    /** Returns a new ad load exception of {@link #TYPE_ALL_ADS}. */
    public static AdLoadException createForAllAds(Exception error) {
      return new AdLoadException(TYPE_ALL_ADS, error);
    }

    /** Returns a new ad load exception of {@link #TYPE_UNEXPECTED}. */
    public static AdLoadException createForUnexpected(RuntimeException error) {
      return new AdLoadException(TYPE_UNEXPECTED, error);
    }

    /** The {@link Type} of the ad load exception. */
    public final @Type int type;

    private AdLoadException(@Type int type, Exception cause) {
      super(cause);
      this.type = type;
    }

    /**
     * Returns the {@link RuntimeException} that caused the exception if its type is {@link
     * #TYPE_UNEXPECTED}.
     */
    public RuntimeException getRuntimeExceptionForUnexpected() {
      checkState(type == TYPE_UNEXPECTED);
      return (RuntimeException) checkNotNull(getCause());
    }
  }

  // Used to identify the content "child" source for CompositeMediaSource.
  private static final MediaPeriodId CHILD_SOURCE_MEDIA_PERIOD_ID =
      new MediaPeriodId(/* periodUid= */ new Object());

  private final MaskingMediaSource contentMediaSource;
  @Nullable final MediaItem.DrmConfiguration contentDrmConfiguration;
  private final MediaSource.Factory adMediaSourceFactory;
  private final AdsLoader adsLoader;
  private final AdViewProvider adViewProvider;
  private final DataSpec adTagDataSpec;
  private final Object adsId;
  private final Handler mainHandler;
  private final Timeline.Period period;
  private final boolean useLazyContentSourcePreparation;
  private final boolean useAdMediaSourceClipping;
  private final List<AdMediaSourceHolder> activeMediaSourceHolders;
  private final Map<ClippingMediaPeriod, Integer> activeContentClippingMediaPeriods;

  // Accessed on the player thread.
  @Nullable private ComponentListener componentListener;
  @Nullable private Timeline contentTimeline;
  @Nullable private AdPlaybackState adPlaybackState;
  private @NullableType AdMediaSourceHolder[][] adMediaSourceHolders;
  @Nullable private Handler playerHandler;

  /**
   * Constructs a new source that inserts ads linearly with the content specified by {@code
   * contentMediaSource}.
   *
   * <p>This is equivalent to passing {@code true} as param {@code useLazyContentSourcePreparation}
   * and {@code false} as param {@code useAdMediaSourceClipping} when calling {@link
   * AdsMediaSource#AdsMediaSource(MediaSource, DataSpec, Object, MediaSource.Factory, AdsLoader,
   * AdViewProvider, boolean, boolean)}.
   *
   * @param contentMediaSource The {@link MediaSource} providing the content to play.
   * @param adTagDataSpec The data specification of the ad tag to load.
   * @param adsId An opaque identifier for ad playback state associated with this instance. Ad
   *     loading and playback state is shared among all playlist items that have the same ads id (by
   *     {@link Object#equals(Object) equality}), so it is important to pass the same identifiers
   *     when constructing playlist items each time the player returns to the foreground.
   * @param adMediaSourceFactory Factory for media sources used to load ad media.
   * @param adsLoader The loader for ads.
   * @param adViewProvider Provider of views for the ad UI.
   */
  public AdsMediaSource(
      MediaSource contentMediaSource,
      DataSpec adTagDataSpec,
      Object adsId,
      Factory adMediaSourceFactory,
      AdsLoader adsLoader,
      AdViewProvider adViewProvider) {
    this(
        contentMediaSource,
        adTagDataSpec,
        adsId,
        adMediaSourceFactory,
        adsLoader,
        adViewProvider,
        /* useLazyContentSourcePreparation= */ true,
        /* useAdMediaSourceClipping= */ false);
  }

  /**
   * Constructs a new source that inserts ads linearly with the content specified by {@code
   * contentMediaSource}.
   *
   * @param contentMediaSource The {@link MediaSource} providing the content to play.
   * @param adTagDataSpec The data specification of the ad tag to load.
   * @param adsId An opaque identifier for ad playback state associated with this instance. Ad
   *     loading and playback state is shared among all playlist items that have the same ads id (by
   *     {@link Object#equals(Object) equality}), so it is important to pass the same identifiers
   *     when constructing playlist items each time the player returns to the foreground.
   * @param adMediaSourceFactory Factory for media sources used to load ad media.
   * @param adsLoader The loader for ads.
   * @param adViewProvider Provider of views for the ad UI.
   * @param useLazyContentSourcePreparation {@code true} if the content source should be prepared
   *     lazily and wait for an {@link AdPlaybackState} to be set before preparing. {@code false} if
   *     the timeline is required {@linkplain AdsLoader#handleContentTimelineChanged(AdsMediaSource,
   *     Timeline) to read ad data from it} to populate the {@link AdPlaybackState} (See {@link
   *     Timeline.Window#manifest} also).
   * @param useAdMediaSourceClipping Whether ad sources should be clipped to the duration declared
   *     in the {@linkplain AdPlaybackState#withAdDurationsUs(int, long...) ad playback state}. If
   *     {@code false}, the ad sources are played to end of stream.
   */
  public AdsMediaSource(
      MediaSource contentMediaSource,
      DataSpec adTagDataSpec,
      Object adsId,
      Factory adMediaSourceFactory,
      AdsLoader adsLoader,
      AdViewProvider adViewProvider,
      boolean useLazyContentSourcePreparation,
      boolean useAdMediaSourceClipping) {
    this.contentMediaSource =
        new MaskingMediaSource(
            contentMediaSource, /* useLazyPreparation= */ useLazyContentSourcePreparation);
    this.contentDrmConfiguration =
        checkNotNull(contentMediaSource.getMediaItem().localConfiguration).drmConfiguration;
    this.adMediaSourceFactory = adMediaSourceFactory;
    this.adsLoader = adsLoader;
    this.adViewProvider = adViewProvider;
    this.adTagDataSpec = adTagDataSpec;
    this.adsId = adsId;
    this.useLazyContentSourcePreparation = useLazyContentSourcePreparation;
    this.useAdMediaSourceClipping = useAdMediaSourceClipping;
    mainHandler = new Handler(Looper.getMainLooper());
    period = new Timeline.Period();
    adMediaSourceHolders = new AdMediaSourceHolder[0][];
    activeMediaSourceHolders = new ArrayList<>();
    activeContentClippingMediaPeriods = new HashMap<>();
    adsLoader.setSupportedContentTypes(adMediaSourceFactory.getSupportedTypes());
  }

  @Override
  public MediaItem getMediaItem() {
    return contentMediaSource.getMediaItem();
  }

  /** Returns the ads ID this source is serving. */
  public Object getAdsId() {
    return adsId;
  }

  @Override
  public boolean canUpdateMediaItem(MediaItem mediaItem) {
    return Objects.equals(getAdsConfiguration(getMediaItem()), getAdsConfiguration(mediaItem))
        && contentMediaSource.canUpdateMediaItem(mediaItem);
  }

  @Override
  public void updateMediaItem(MediaItem mediaItem) {
    contentMediaSource.updateMediaItem(mediaItem);
  }

  @Override
  protected void prepareSourceInternal(@Nullable TransferListener mediaTransferListener) {
    super.prepareSourceInternal(mediaTransferListener);
    this.playerHandler = Util.createHandlerForCurrentLooper();
    ComponentListener componentListener = new ComponentListener(playerHandler);
    this.componentListener = componentListener;
    contentTimeline = contentMediaSource.getTimeline();
    prepareChildSource(CHILD_SOURCE_MEDIA_PERIOD_ID, contentMediaSource);
    mainHandler.post(
        () ->
            adsLoader.start(
                /* adsMediaSource= */ this,
                adTagDataSpec,
                adsId,
                adViewProvider,
                componentListener));
  }

  @Override
  public MediaPeriod createPeriod(MediaPeriodId id, Allocator allocator, long startPositionUs) {
    AdPlaybackState adPlaybackState = checkNotNull(this.adPlaybackState);
    if (adPlaybackState.adGroupCount > 0 && id.isAd()) {
      int adGroupIndex = id.adGroupIndex;
      int adIndexInAdGroup = id.adIndexInAdGroup;
      if (adMediaSourceHolders[adGroupIndex].length <= adIndexInAdGroup) {
        int adCount = adIndexInAdGroup + 1;
        adMediaSourceHolders[adGroupIndex] =
            Arrays.copyOf(adMediaSourceHolders[adGroupIndex], adCount);
      }
      @Nullable
      AdMediaSourceHolder adMediaSourceHolder =
          adMediaSourceHolders[adGroupIndex][adIndexInAdGroup];
      if (adMediaSourceHolder == null) {
        long endPositionUs = C.TIME_END_OF_SOURCE;
        if (useAdMediaSourceClipping) {
          AdGroup adGroup = checkNotNull(adPlaybackState.getAdGroup(id.adGroupIndex));
          if (adGroup.durationsUs.length > adIndexInAdGroup) {
            long adDurationUs = adGroup.durationsUs[adIndexInAdGroup];
            if (adDurationUs != C.TIME_UNSET) {
              endPositionUs = adDurationUs;
            }
          }
        }
        adMediaSourceHolder = new AdMediaSourceHolder(id, endPositionUs);
        adMediaSourceHolders[adGroupIndex][adIndexInAdGroup] = adMediaSourceHolder;
        activeMediaSourceHolders.add(adMediaSourceHolder);
        maybeUpdateAdMediaSources();
      }
      return adMediaSourceHolder.createMediaPeriod(
          id, allocator, startPositionUs, useAdMediaSourceClipping);
    } else {
      MediaPeriodId contentMediaPeriodId = new MediaPeriodId(id.periodUid, id.windowSequenceNumber);
      MaskingMediaPeriod maskingMediaPeriod =
          new MaskingMediaPeriod(contentMediaPeriodId, allocator, startPositionUs);
      maskingMediaPeriod.setMediaSource(contentMediaSource);
      maskingMediaPeriod.createPeriod(contentMediaPeriodId);
      if (id.nextAdGroupIndex == C.INDEX_UNSET) {
        return maskingMediaPeriod;
      }
      long nextAdGroupTimeUs = adPlaybackState.getAdGroup(id.nextAdGroupIndex).timeUs;
      ClippingMediaPeriod clippingMediaPeriod =
          new ClippingMediaPeriod(
              maskingMediaPeriod,
              /* enableInitialDiscontinuity= */ true,
              /* startUs= */ 0,
              /* endUs= */ nextAdGroupTimeUs);
      activeContentClippingMediaPeriods.put(clippingMediaPeriod, id.nextAdGroupIndex);
      return clippingMediaPeriod;
    }
  }

  @Override
  public void releasePeriod(MediaPeriod mediaPeriod) {
    MaskingMediaPeriod maskingMediaPeriod =
        (MaskingMediaPeriod)
            (mediaPeriod instanceof ClippingMediaPeriod
                ? ((ClippingMediaPeriod) mediaPeriod).mediaPeriod
                : mediaPeriod);
    MediaPeriodId id = maskingMediaPeriod.id;
    if (id.isAd()) {
      AdMediaSourceHolder adMediaSourceHolder =
          checkNotNull(adMediaSourceHolders[id.adGroupIndex][id.adIndexInAdGroup]);
      adMediaSourceHolder.releaseMediaPeriod(mediaPeriod);
      if (adMediaSourceHolder.isInactive()) {
        adMediaSourceHolder.release();
        adMediaSourceHolders[id.adGroupIndex][id.adIndexInAdGroup] = null;
        activeMediaSourceHolders.remove(adMediaSourceHolder);
      }
    } else {
      if (mediaPeriod instanceof ClippingMediaPeriod) {
        activeContentClippingMediaPeriods.remove(mediaPeriod);
      }
      maskingMediaPeriod.releasePeriod();
    }
  }

  @Override
  protected void releaseSourceInternal() {
    super.releaseSourceInternal();
    ComponentListener componentListener = checkNotNull(this.componentListener);
    this.componentListener = null;
    this.playerHandler = null;
    componentListener.stop();
    contentTimeline = null;
    adPlaybackState = null;
    adMediaSourceHolders = new AdMediaSourceHolder[0][];
    mainHandler.post(() -> adsLoader.stop(/* adsMediaSource= */ this, componentListener));
  }

  @Override
  protected void onChildSourceInfoRefreshed(
      MediaPeriodId childSourceId, MediaSource mediaSource, Timeline newTimeline) {
    if (childSourceId.isAd()) {
      int adGroupIndex = childSourceId.adGroupIndex;
      int adIndexInAdGroup = childSourceId.adIndexInAdGroup;
      checkNotNull(adMediaSourceHolders[adGroupIndex][adIndexInAdGroup])
          .handleSourceInfoRefresh(newTimeline);
      maybeUpdateSourceInfo();
    } else {
      checkArgument(newTimeline.getPeriodCount() == 1);
      contentTimeline = newTimeline;
      mainHandler.post(
          () -> {
            boolean sourceInfoUpdated = adsLoader.handleContentTimelineChanged(this, newTimeline);
            // The ad playback state must not be updated when lazy preparation is used.
            checkState(!sourceInfoUpdated || !useLazyContentSourcePreparation);
            // If the source isn't updated by the ads loader we do, if not already published.
            if (!sourceInfoUpdated && !useLazyContentSourcePreparation) {
              checkNotNull(playerHandler).post(this::maybeUpdateSourceInfo);
            }
          });
      if (useLazyContentSourcePreparation) {
        // If lazy preparation is used, the ads loader is not allowed to update the ad playback
        // state on timeline change. We can synchronously publish the timeline as early as possible.
        maybeUpdateSourceInfo();
      }
    }
  }

  @Override
  protected MediaPeriodId getMediaPeriodIdForChildMediaPeriodId(
      MediaPeriodId childSourceId, MediaPeriodId mediaPeriodId) {
    // The child id for the content period is just CHILD_SOURCE_MEDIA_PERIOD_ID. That's why
    // we need to forward the reported mediaPeriodId in this case.
    return childSourceId.isAd() ? childSourceId : mediaPeriodId;
  }

  // Internal methods.

  private void onAdPlaybackState(AdPlaybackState adPlaybackState) {
    if (this.adPlaybackState == null) {
      int playableAdGroupCount =
          adPlaybackState.adGroupCount
              - (adPlaybackState.endsWithLivePostrollPlaceHolder() ? 1 : 0);
      adMediaSourceHolders = new AdMediaSourceHolder[playableAdGroupCount][];
      Arrays.fill(adMediaSourceHolders, new AdMediaSourceHolder[0]);
    } else {
      int adGroupInsertionCount =
          checkValidAdPlaybackStateUpdate(this.adPlaybackState, adPlaybackState);
      if (adGroupInsertionCount > 0) {
        adMediaSourceHolders =
            growAdMediaSourceHolderGrid(adMediaSourceHolders, adGroupInsertionCount);
      }
      if (useAdMediaSourceClipping) {
        for (int i = 0; i < activeMediaSourceHolders.size(); i++) {
          AdMediaSourceHolder adMediaSourceHolder = activeMediaSourceHolders.get(i);
          MediaPeriodId id = adMediaSourceHolder.id;
          long adDurationUs =
              adPlaybackState.getAdGroup(id.adGroupIndex).durationsUs[id.adIndexInAdGroup];
          if (adDurationUs != C.TIME_UNSET) {
            adMediaSourceHolder.setEndPositionUs(adDurationUs);
          }
        }
      }
      for (Map.Entry<ClippingMediaPeriod, Integer> activeClippingPeriod :
          activeContentClippingMediaPeriods.entrySet()) {
        int nextAdGroupIndex = activeClippingPeriod.getValue();
        long nextAdGroupTimeUs = adPlaybackState.getAdGroup(nextAdGroupIndex).timeUs;
        activeClippingPeriod
            .getKey()
            .updateClipping(/* startUs= */ 0, /* endUs= */ nextAdGroupTimeUs);
      }
    }
    this.adPlaybackState = adPlaybackState;
    maybeUpdateAdMediaSources();
    maybeUpdateSourceInfo();
  }

  private static int checkValidAdPlaybackStateUpdate(
      AdPlaybackState oldAdPlaybackState, AdPlaybackState newAdPlaybackState) {
    checkState(
        oldAdPlaybackState.endsWithLivePostrollPlaceHolder()
            == newAdPlaybackState.endsWithLivePostrollPlaceHolder());
    int insertionCount = newAdPlaybackState.adGroupCount - oldAdPlaybackState.adGroupCount;
    checkState(insertionCount >= 0);
    for (int i = newAdPlaybackState.removedAdGroupCount; i < oldAdPlaybackState.adGroupCount; i++) {
      AdGroup oldAdGroup = oldAdPlaybackState.getAdGroup(i);
      if (oldAdGroup.isLivePostrollPlaceholder()) {
        // Post-roll placeholder must be at the last index.
        checkState(i == oldAdPlaybackState.adGroupCount - 1);
        break;
      }
      AdGroup newAdGroup = newAdPlaybackState.getAdGroup(i);
      checkState(oldAdGroup.timeUs == newAdGroup.timeUs);
      if (oldAdGroup.hasUnplayedAds()) {
        checkState(oldAdGroup.count <= newAdGroup.count);
        for (int j = 0; j < oldAdGroup.count; j++) {
          MediaItem oldMediaItem = oldAdGroup.mediaItems[j];
          if (oldMediaItem != null && oldAdGroup.states[j] == AdPlaybackState.AD_STATE_AVAILABLE) {
            checkState(oldMediaItem.equals(newAdGroup.mediaItems[j]));
          }
        }
      }
    }
    return insertionCount;
  }

  private static @NullableType AdMediaSourceHolder[][] growAdMediaSourceHolderGrid(
      @NullableType AdMediaSourceHolder[][] grid, int insertionCount) {
    @NullableType
    AdMediaSourceHolder[][] grownGrid = new AdMediaSourceHolder[grid.length + insertionCount][];
    System.arraycopy(grid, 0, grownGrid, 0, grid.length);
    for (int i = grid.length; i < grownGrid.length; i++) {
      grownGrid[i] = new AdMediaSourceHolder[0];
    }
    return grownGrid;
  }

  /**
   * Initializes any {@link AdMediaSourceHolder AdMediaSourceHolders} where the ad media URI is
   * newly known.
   */
  private void maybeUpdateAdMediaSources() {
    @Nullable AdPlaybackState adPlaybackState = this.adPlaybackState;
    if (adPlaybackState == null) {
      return;
    }
    for (int adGroupIndex = 0; adGroupIndex < adMediaSourceHolders.length; adGroupIndex++) {
      for (int adIndexInAdGroup = 0;
          adIndexInAdGroup < this.adMediaSourceHolders[adGroupIndex].length;
          adIndexInAdGroup++) {
        @Nullable
        AdMediaSourceHolder adMediaSourceHolder =
            this.adMediaSourceHolders[adGroupIndex][adIndexInAdGroup];
        AdGroup adGroup = adPlaybackState.getAdGroup(adGroupIndex);
        if (adMediaSourceHolder != null
            && !adMediaSourceHolder.hasMediaSource()
            && adIndexInAdGroup < adGroup.mediaItems.length) {
          @Nullable MediaItem adMediaItem = adGroup.mediaItems[adIndexInAdGroup];
          if (adMediaItem != null) {
            // Propagate the content's DRM config into the ad media source.
            if (contentDrmConfiguration != null) {
              adMediaItem =
                  adMediaItem.buildUpon().setDrmConfiguration(contentDrmConfiguration).build();
            }
            MediaSource adMediaSource = adMediaSourceFactory.createMediaSource(adMediaItem);
            adMediaSourceHolder.initializeWithMediaSource(adMediaSource, adMediaItem);
          }
        }
      }
    }
  }

  private void maybeUpdateSourceInfo() {
    @Nullable Timeline contentTimeline = this.contentTimeline;
    if (adPlaybackState != null && contentTimeline != null) {
      if (adPlaybackState.adGroupCount == 0) {
        refreshSourceInfo(contentTimeline);
      } else {
        adPlaybackState = adPlaybackState.withAdDurationsUs(getAdDurationsUs());
        refreshSourceInfo(new SinglePeriodAdTimeline(contentTimeline, adPlaybackState));
      }
    }
  }

  @RequiresNonNull("adPlaybackState")
  private long[][] getAdDurationsUs() {
    AdPlaybackState adPlaybackState = checkNotNull(this.adPlaybackState);
    boolean hasPostRollPlaceholder = adPlaybackState.endsWithLivePostrollPlaceHolder();
    int adGroupCount = adMediaSourceHolders.length + (hasPostRollPlaceholder ? 1 : 0);
    long[][] adDurationsUs = new long[adGroupCount][];
    for (int i = 0; i < adMediaSourceHolders.length; i++) {
      int adCount =
          useAdMediaSourceClipping
              ? Math.max(adPlaybackState.getAdGroup(i).count, 0)
              : adMediaSourceHolders[i].length;
      adDurationsUs[i] = new long[adCount];
      for (int j = 0; j < adCount; j++) {
        long adDurationUs =
            adPlaybackState.getAdGroup(i).durationsUs.length > j
                ? adPlaybackState.getAdGroup(i).durationsUs[j]
                : C.TIME_UNSET;
        if (adDurationUs != C.TIME_UNSET && useAdMediaSourceClipping) {
          adDurationsUs[i][j] = adDurationUs;
        } else if (adMediaSourceHolders[i].length > j && adMediaSourceHolders[i][j] != null) {
          adDurationsUs[i][j] = adMediaSourceHolders[i][j].getDurationUs();
        } else {
          adDurationsUs[i][j] = C.TIME_UNSET;
        }
      }
    }
    if (hasPostRollPlaceholder) {
      // Set the pseudo-durations of the placeholder that is not represented by the holders.
      adDurationsUs[adGroupCount - 1] = new long[0];
    }
    return adDurationsUs;
  }

  @Nullable
  private static MediaItem.AdsConfiguration getAdsConfiguration(MediaItem mediaItem) {
    return mediaItem.localConfiguration == null
        ? null
        : mediaItem.localConfiguration.adsConfiguration;
  }

  /** Listener for component events. All methods are called on the main thread. */
  private final class ComponentListener implements AdsLoader.EventListener {

    private final Handler playerHandler;

    private volatile boolean stopped;

    /**
     * Creates new listener which forwards ad playback states on the creating thread and all other
     * events on the external event listener thread.
     */
    public ComponentListener(Handler playerHandler) {
      this.playerHandler = playerHandler;
    }

    /** Stops event delivery from this instance. */
    public void stop() {
      stopped = true;
      playerHandler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onAdPlaybackState(final AdPlaybackState adPlaybackState) {
      if (stopped) {
        return;
      }
      playerHandler.post(
          () -> {
            if (stopped) {
              return;
            }
            AdsMediaSource.this.onAdPlaybackState(adPlaybackState);
          });
    }

    @Override
    public void onAdLoadError(final AdLoadException error, DataSpec dataSpec) {
      if (stopped) {
        return;
      }
      createEventDispatcher(/* mediaPeriodId= */ null)
          .loadError(
              new LoadEventInfo.Builder(
                      LoadEventInfo.getNewId(),
                      dataSpec,
                      /* elapsedRealtimeMs= */ SystemClock.elapsedRealtime())
                  .build(),
              C.DATA_TYPE_AD,
              error,
              /* wasCanceled= */ true);
    }
  }

  private final class AdPrepareListener implements MaskingMediaPeriod.PrepareListener {

    private final MediaItem adMediaItem;

    public AdPrepareListener(MediaItem adMediaItem) {
      this.adMediaItem = adMediaItem;
    }

    @Override
    public void onPrepareComplete(MediaPeriodId mediaPeriodId) {
      mainHandler.post(
          () ->
              adsLoader.handlePrepareComplete(
                  /* adsMediaSource= */ AdsMediaSource.this,
                  mediaPeriodId.adGroupIndex,
                  mediaPeriodId.adIndexInAdGroup));
    }

    @Override
    public void onPrepareError(MediaPeriodId mediaPeriodId, IOException exception) {
      createEventDispatcher(mediaPeriodId)
          .loadError(
              new LoadEventInfo.Builder(
                      LoadEventInfo.getNewId(),
                      new DataSpec(checkNotNull(adMediaItem.localConfiguration).uri),
                      /* elapsedRealtimeMs= */ SystemClock.elapsedRealtime())
                  .build(),
              C.DATA_TYPE_AD,
              AdLoadException.createForAd(exception),
              /* wasCanceled= */ true);
      mainHandler.post(
          () ->
              adsLoader.handlePrepareError(
                  /* adsMediaSource= */ AdsMediaSource.this,
                  mediaPeriodId.adGroupIndex,
                  mediaPeriodId.adIndexInAdGroup,
                  exception));
    }
  }

  private final class AdMediaSourceHolder {

    private final MediaPeriodId id;
    private final List<MediaPeriod> activeMediaPeriods;

    private @MonotonicNonNull MediaItem adMediaItem;
    private @MonotonicNonNull MediaSource adMediaSource;
    private @MonotonicNonNull Timeline timeline;
    private long endPositionUs;

    private AdMediaSourceHolder(MediaPeriodId id, long endPositionUs) {
      this.id = id;
      this.endPositionUs = endPositionUs;
      activeMediaPeriods = new ArrayList<>();
    }

    private void initializeWithMediaSource(MediaSource adMediaSource, MediaItem adMediaItem) {
      this.adMediaSource = adMediaSource;
      this.adMediaItem = adMediaItem;
      for (int i = 0; i < activeMediaPeriods.size(); i++) {
        MaskingMediaPeriod maskingMediaPeriod = getActiveMaskingMediaPeriod(i);
        maskingMediaPeriod.setMediaSource(adMediaSource);
        maskingMediaPeriod.setPrepareListener(new AdPrepareListener(adMediaItem));
      }
      prepareChildSource(id, adMediaSource);
    }

    private MediaPeriod createMediaPeriod(
        MediaPeriodId id, Allocator allocator, long startPositionUs, boolean useClipping) {
      MaskingMediaPeriod maskingMediaPeriod =
          new MaskingMediaPeriod(id, allocator, startPositionUs);
      MediaPeriod mediaPeriod =
          useClipping
              ? new ClippingMediaPeriod(
                  maskingMediaPeriod,
                  /* enableInitialDiscontinuity= */ false,
                  startPositionUs,
                  endPositionUs)
              : maskingMediaPeriod;
      activeMediaPeriods.add(mediaPeriod);
      if (adMediaSource != null) {
        maskingMediaPeriod.setMediaSource(adMediaSource);
        maskingMediaPeriod.setPrepareListener(new AdPrepareListener(checkNotNull(adMediaItem)));
      }
      if (timeline != null) {
        Object periodUid = timeline.getUidOfPeriod(/* periodIndex= */ 0);
        MediaPeriodId adSourceMediaPeriodId = new MediaPeriodId(periodUid, id.windowSequenceNumber);
        maskingMediaPeriod.createPeriod(adSourceMediaPeriodId);
      }
      return mediaPeriod;
    }

    private void handleSourceInfoRefresh(Timeline timeline) {
      checkArgument(timeline.getPeriodCount() == 1);
      if (this.timeline == null) {
        Object periodUid = timeline.getUidOfPeriod(/* periodIndex= */ 0);
        for (int i = 0; i < activeMediaPeriods.size(); i++) {
          MaskingMediaPeriod maskingMediaPeriod = getActiveMaskingMediaPeriod(i);
          MediaPeriodId adSourceMediaPeriodId =
              new MediaPeriodId(periodUid, maskingMediaPeriod.id.windowSequenceNumber);
          maskingMediaPeriod.createPeriod(adSourceMediaPeriodId);
        }
        setEndPositionUs(endPositionUs);
      }
      this.timeline = timeline;
    }

    private void setEndPositionUs(long endPositionUs) {
      if (!useAdMediaSourceClipping
          || this.endPositionUs != C.TIME_END_OF_SOURCE
          || endPositionUs == C.TIME_END_OF_SOURCE) {
        return;
      }
      this.endPositionUs = endPositionUs;
      for (int i = 0; i < activeMediaPeriods.size(); i++) {
        if (activeMediaPeriods.get(i) instanceof ClippingMediaPeriod) {
          ((ClippingMediaPeriod) activeMediaPeriods.get(i))
              .updateClipping(/* startUs= */ 0, endPositionUs);
        }
      }
    }

    private long getDurationUs() {
      return timeline == null
          ? C.TIME_UNSET
          : timeline.getPeriod(/* periodIndex= */ 0, period).getDurationUs();
    }

    private void releaseMediaPeriod(MediaPeriod mediaPeriod) {
      activeMediaPeriods.remove(mediaPeriod);
      MaskingMediaPeriod maskingMediaPeriod =
          (MaskingMediaPeriod)
              (mediaPeriod instanceof ClippingMediaPeriod
                  ? ((ClippingMediaPeriod) mediaPeriod).mediaPeriod
                  : mediaPeriod);
      maskingMediaPeriod.releasePeriod();
    }

    private void release() {
      if (hasMediaSource()) {
        releaseChildSource(id);
      }
    }

    private boolean hasMediaSource() {
      return adMediaSource != null;
    }

    private boolean isInactive() {
      return activeMediaPeriods.isEmpty();
    }

    private MaskingMediaPeriod getActiveMaskingMediaPeriod(int activeMediaPeriodIndex) {
      MediaPeriod mediaPeriod = activeMediaPeriods.get(activeMediaPeriodIndex);
      return (MaskingMediaPeriod)
          (mediaPeriod instanceof ClippingMediaPeriod
              ? ((ClippingMediaPeriod) mediaPeriod).mediaPeriod
              : mediaPeriod);
    }
  }
}
