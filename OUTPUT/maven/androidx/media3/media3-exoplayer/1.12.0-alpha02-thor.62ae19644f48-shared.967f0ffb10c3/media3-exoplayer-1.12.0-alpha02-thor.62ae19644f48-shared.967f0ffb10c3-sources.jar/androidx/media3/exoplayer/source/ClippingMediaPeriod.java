/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.exoplayer.source;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.max;
import static java.lang.Math.min;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Flags;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.StreamKey;
import androidx.media3.common.util.ExperimentalApi;
import androidx.media3.common.util.NullableType;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.exoplayer.FormatHolder;
import androidx.media3.exoplayer.LoadingInfo;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.exoplayer.source.ClippingMediaSource.IllegalClippingException;
import androidx.media3.exoplayer.trackselection.ExoTrackSelection;
import java.io.IOException;
import java.util.List;

/**
 * Wraps a {@link MediaPeriod} and clips its {@link SampleStream}s to provide a subsequence of their
 * samples.
 */
@UnstableApi
public final class ClippingMediaPeriod implements MediaPeriod, MediaPeriod.Callback {

  /** The {@link MediaPeriod} wrapped by this clipping media period. */
  public final MediaPeriod mediaPeriod;

  private final boolean enableClippingInMediaPeriod;

  @Nullable private MediaPeriod.Callback callback;
  private @NullableType ClippingSampleStream[] sampleStreams;
  private long pendingInitialDiscontinuityPositionUs;
  private boolean hasProcessedInitialDiscontinuity;
  private boolean usesStreamPrerollFlags;
  private long lastReportedDiscontinuityUs;
  /* package */ long startUs;
  /* package */ long endUs;
  @Nullable private IllegalClippingException clippingError;
  private boolean isPeriodClippingEndPosition;

  /**
   * Creates a new clipping media period that provides a clipped view of the specified {@link
   * MediaPeriod}'s sample streams.
   *
   * <p>If the start point is guaranteed to be a key frame, pass {@code false} to {@code
   * enableInitialPositionDiscontinuity} to suppress an initial discontinuity when the period is
   * first read from.
   *
   * @param mediaPeriod The media period to clip.
   * @param enableInitialDiscontinuity Whether the initial discontinuity should be enabled.
   * @param startUs The clipping start time, in microseconds.
   * @param endUs The clipping end time, in microseconds, or {@link C#TIME_END_OF_SOURCE} to
   *     indicate the end of the period.
   */
  public ClippingMediaPeriod(
      MediaPeriod mediaPeriod, boolean enableInitialDiscontinuity, long startUs, long endUs) {
    this(
        mediaPeriod,
        enableInitialDiscontinuity,
        startUs,
        endUs,
        Flags.isEnabled(Flags.FLAG_ENABLE_CLIPPING_IN_MEDIA_PERIOD));
  }

  /**
   * Creates a new clipping media period that provides a clipped view of the specified {@link
   * MediaPeriod}'s sample streams.
   *
   * <p>If the start point is guaranteed to be a key frame, pass {@code false} to {@code
   * enableInitialDiscontinuity} to suppress an initial discontinuity when a period is first read
   * from.
   *
   * @param mediaPeriod The media period to clip.
   * @param enableInitialDiscontinuity Whether the initial discontinuity should be enabled.
   * @param startUs The clipping start time, in microseconds.
   * @param endUs The clipping end time, in microseconds, or {@link C#TIME_END_OF_SOURCE} to
   *     indicate the end of the period.
   * @param enableClippingInMediaPeriod Whether to delegate end-position clipping to {@link
   *     MediaPeriod} instances.
   */
  @ExperimentalApi // TODO: b/474538573 - Remove once clipping in media period is default.
  public ClippingMediaPeriod(
      MediaPeriod mediaPeriod,
      boolean enableInitialDiscontinuity,
      long startUs,
      long endUs,
      boolean enableClippingInMediaPeriod) {
    this.mediaPeriod = mediaPeriod;
    sampleStreams = new ClippingSampleStream[0];
    pendingInitialDiscontinuityPositionUs = enableInitialDiscontinuity ? startUs : C.TIME_UNSET;
    lastReportedDiscontinuityUs = C.TIME_UNSET;
    this.enableClippingInMediaPeriod = enableClippingInMediaPeriod;
    updateClipping(startUs, endUs);
  }

  /**
   * Updates the clipping start/end times for this period, in microseconds.
   *
   * @param startUs The clipping start time, in microseconds.
   * @param endUs The clipping end time, in microseconds, or {@link C#TIME_END_OF_SOURCE} to
   *     indicate the end of the period.
   */
  public void updateClipping(long startUs, long endUs) {
    this.startUs = startUs;
    this.endUs = endUs;
    if (enableClippingInMediaPeriod) {
      long periodEndPositionUs = mediaPeriod.setEndPositionUs(endUs);
      checkState(
          periodEndPositionUs == C.TIME_END_OF_SOURCE || periodEndPositionUs == endUs,
          "Period updating end positions not supported, %s!=%s",
          periodEndPositionUs,
          endUs);
      this.isPeriodClippingEndPosition = periodEndPositionUs == endUs;
    }
  }

  /**
   * Sets a clipping error detected by the media source so that it can be thrown as a period error
   * at the next opportunity.
   *
   * @param clippingError The clipping error.
   */
  public void setClippingError(IllegalClippingException clippingError) {
    this.clippingError = clippingError;
  }

  @Override
  public void prepare(MediaPeriod.Callback callback, long positionUs) {
    this.callback = callback;
    mediaPeriod.prepare(this, positionUs);
  }

  @Override
  public void maybeThrowPrepareError() throws IOException {
    if (clippingError != null) {
      throw clippingError;
    }
    mediaPeriod.maybeThrowPrepareError();
  }

  @Override
  public List<StreamKey> getStreamKeys(List<ExoTrackSelection> trackSelections) {
    return mediaPeriod.getStreamKeys(trackSelections);
  }

  @Override
  public TrackGroupArray getTrackGroups() {
    return mediaPeriod.getTrackGroups();
  }

  @Override
  public long selectTracks(
      @NullableType ExoTrackSelection[] selections,
      boolean[] mayRetainStreamFlags,
      @NullableType SampleStream[] streams,
      boolean[] streamResetFlags,
      long positionUs) {
    sampleStreams = new ClippingSampleStream[streams.length];
    @NullableType SampleStream[] childStreams = new SampleStream[streams.length];
    for (int i = 0; i < streams.length; i++) {
      sampleStreams[i] = (ClippingSampleStream) streams[i];
      childStreams[i] = sampleStreams[i] != null ? sampleStreams[i].childStream : null;
    }
    long realEnablePositionUs =
        mediaPeriod.selectTracks(
            selections, mayRetainStreamFlags, childStreams, streamResetFlags, positionUs);
    long correctedEnablePositionUs =
        enforceClippingRange(realEnablePositionUs, /* minPositionUs= */ positionUs, endUs);

    boolean anyTrackHasPreroll = false;
    for (int i = 0; i < streams.length; i++) {
      if (childStreams[i] == null) {
        sampleStreams[i] = null;
      } else if (sampleStreams[i] == null || sampleStreams[i].childStream != childStreams[i]) {
        boolean hasPreroll =
            isPendingInitialDiscontinuity()
                && shouldKeepInitialDiscontinuity(realEnablePositionUs, positionUs, selections, i);
        sampleStreams[i] = new ClippingSampleStream(checkNotNull(childStreams[i]), hasPreroll);
        anyTrackHasPreroll |= hasPreroll;
      }
      streams[i] = sampleStreams[i];
    }
    pendingInitialDiscontinuityPositionUs =
        anyTrackHasPreroll ? correctedEnablePositionUs : C.TIME_UNSET;
    if (usesStreamPrerollFlags) {
      hasProcessedInitialDiscontinuity = true;
    }

    return correctedEnablePositionUs;
  }

  @Override
  public void discardBuffer(long positionUs, boolean toKeyframe) {
    mediaPeriod.discardBuffer(positionUs, toKeyframe);
  }

  @Override
  public void reevaluateBuffer(long positionUs) {
    mediaPeriod.reevaluateBuffer(positionUs);
  }

  @Override
  public void setUsesStreamPrerollFlags() {
    this.usesStreamPrerollFlags = true;
    mediaPeriod.setUsesStreamPrerollFlags();
  }

  @Override
  public long readDiscontinuity() {
    if (isPendingInitialDiscontinuity()) {
      hasProcessedInitialDiscontinuity = true;
      long initialDiscontinuityUs = pendingInitialDiscontinuityPositionUs;
      pendingInitialDiscontinuityPositionUs = C.TIME_UNSET;
      lastReportedDiscontinuityUs = initialDiscontinuityUs;
      // Always read an initial discontinuity from the child, and use it if set.
      long childDiscontinuityUs = readDiscontinuity();
      return childDiscontinuityUs != C.TIME_UNSET ? childDiscontinuityUs : initialDiscontinuityUs;
    }
    long discontinuityUs = mediaPeriod.readDiscontinuity();
    if (discontinuityUs == C.TIME_UNSET) {
      return C.TIME_UNSET;
    }
    discontinuityUs = enforceClippingRange(discontinuityUs, startUs, endUs);
    if (discontinuityUs == lastReportedDiscontinuityUs) {
      // Already reported, don't force reset rendering pipeline again.
      return C.TIME_UNSET;
    }
    lastReportedDiscontinuityUs = discontinuityUs;
    return discontinuityUs;
  }

  @Override
  public long getBufferedPositionUs() {
    long bufferedPositionUs = mediaPeriod.getBufferedPositionUs();
    if (isPeriodClippingEndPosition) {
      return endUs != C.TIME_END_OF_SOURCE && bufferedPositionUs != C.TIME_END_OF_SOURCE
          ? min(endUs, bufferedPositionUs)
          : bufferedPositionUs;
    }
    if (bufferedPositionUs == C.TIME_END_OF_SOURCE
        || (endUs != C.TIME_END_OF_SOURCE && bufferedPositionUs >= endUs)) {
      return C.TIME_END_OF_SOURCE;
    }
    return bufferedPositionUs;
  }

  @Override
  public long seekToUs(long positionUs) {
    pendingInitialDiscontinuityPositionUs = C.TIME_UNSET;
    for (@Nullable ClippingSampleStream sampleStream : sampleStreams) {
      if (sampleStream != null) {
        sampleStream.clearSentEos();
      }
    }
    return enforceClippingRange(mediaPeriod.seekToUs(positionUs), startUs, endUs);
  }

  @Override
  public long getAdjustedSeekPositionUs(long positionUs, SeekParameters seekParameters) {
    if (positionUs == startUs) {
      // Never adjust seeks to the start of the clipped view.
      return startUs;
    }
    SeekParameters clippedSeekParameters = clipSeekParameters(positionUs, seekParameters);
    return mediaPeriod.getAdjustedSeekPositionUs(positionUs, clippedSeekParameters);
  }

  @Override
  public long getNextLoadPositionUs() {
    long nextLoadPositionUs = mediaPeriod.getNextLoadPositionUs();
    if (isPeriodClippingEndPosition) {
      return endUs != C.TIME_END_OF_SOURCE && nextLoadPositionUs != C.TIME_END_OF_SOURCE
          ? min(endUs, nextLoadPositionUs)
          : nextLoadPositionUs;
    }
    if (nextLoadPositionUs == C.TIME_END_OF_SOURCE
        || (endUs != C.TIME_END_OF_SOURCE && nextLoadPositionUs >= endUs)) {
      return C.TIME_END_OF_SOURCE;
    }
    return nextLoadPositionUs;
  }

  @Override
  public boolean continueLoading(LoadingInfo loadingInfo) {
    return mediaPeriod.continueLoading(loadingInfo);
  }

  @Override
  public boolean isLoading() {
    return mediaPeriod.isLoading();
  }

  // MediaPeriod.Callback implementation.

  @Override
  public void onPrepared(MediaPeriod mediaPeriod) {
    if (clippingError != null) {
      return;
    }
    checkNotNull(callback).onPrepared(this);
  }

  @Override
  public void onContinueLoadingRequested(MediaPeriod source) {
    checkNotNull(callback).onContinueLoadingRequested(this);
  }

  /* package */ boolean isPendingInitialDiscontinuity() {
    return pendingInitialDiscontinuityPositionUs != C.TIME_UNSET
        && !hasProcessedInitialDiscontinuity;
  }

  private SeekParameters clipSeekParameters(long positionUs, SeekParameters seekParameters) {
    long toleranceBeforeUs =
        Util.constrainValue(
            seekParameters.toleranceBeforeUs, /* min= */ 0, /* max= */ positionUs - startUs);
    long toleranceAfterUs =
        Util.constrainValue(
            seekParameters.toleranceAfterUs,
            /* min= */ 0,
            /* max= */ endUs == C.TIME_END_OF_SOURCE ? Long.MAX_VALUE : endUs - positionUs);
    if (toleranceBeforeUs == seekParameters.toleranceBeforeUs
        && toleranceAfterUs == seekParameters.toleranceAfterUs) {
      return seekParameters;
    } else {
      return new SeekParameters(toleranceBeforeUs, toleranceAfterUs);
    }
  }

  private static boolean shouldKeepInitialDiscontinuity(
      long enablePositionUs,
      long requestedPositionUs,
      @NullableType ExoTrackSelection[] selections,
      int streamIndex) {
    // If the source adjusted the enable position to be before the requested position, we need to
    // report a discontinuity to ensure renderers decode-only the samples before the requested start
    // position.
    if (enablePositionUs < requestedPositionUs) {
      return true;
    }
    // If the enable position is non-zero, the clipping sample streams will adjust
    // timestamps on buffers they read from the unclipped sample streams. These adjusted buffer
    // timestamps can be negative, because sample streams provide buffers starting at a key-frame,
    // which may be before the clipping start point. When the renderer reads a buffer with a
    // negative timestamp, its offset timestamp can jump backwards compared to the last timestamp
    // read in the previous period. Renderer implementations may not allow this, so we signal a
    // discontinuity which resets the renderers before they read the clipping sample stream.
    // However, for tracks where all samples are sync samples, we assume they have random access
    // seek behaviour and do not need an initial discontinuity to reset the renderer.
    if (enablePositionUs != 0) {
      if (selections[streamIndex] != null) {
        Format selectedFormat = selections[streamIndex].getSelectedFormat();
        return !MimeTypes.allSamplesAreSyncSamples(
            selectedFormat.sampleMimeType, selectedFormat.codecs);
      }
    }
    return false;
  }

  private static long enforceClippingRange(
      long positionUs, long minPositionUs, long maxPositionUs) {
    positionUs = max(positionUs, minPositionUs);
    if (maxPositionUs != C.TIME_END_OF_SOURCE) {
      positionUs = min(positionUs, maxPositionUs);
    }
    return positionUs;
  }

  /** Wraps a {@link SampleStream} and clips its samples. */
  private final class ClippingSampleStream implements SampleStream {
    private final SampleStream childStream;
    private final boolean hasPreroll;
    private boolean sentEos;

    private ClippingSampleStream(SampleStream childStream, boolean hasPreroll) {
      this.childStream = childStream;
      this.hasPreroll = hasPreroll;
    }

    private void clearSentEos() {
      sentEos = false;
    }

    @Override
    public boolean isReady() {
      return !isPendingInitialDiscontinuity() && childStream.isReady();
    }

    @Override
    public void maybeThrowError() throws IOException {
      childStream.maybeThrowError();
    }

    @Override
    public int readData(
        FormatHolder formatHolder, DecoderInputBuffer buffer, @ReadFlags int readFlags) {
      if (isPendingInitialDiscontinuity()) {
        return C.RESULT_NOTHING_READ;
      }
      if (isPeriodClippingEndPosition) {
        @ReadDataResult int result = childStream.readData(formatHolder, buffer, readFlags);
        if (result == C.RESULT_FORMAT_READ) {
          updateDecoderDelayPaddingForClipping(formatHolder, startUs, endUs);
          return C.RESULT_FORMAT_READ;
        }
        return result;
      }
      if (sentEos) {
        buffer.setFlags(C.BUFFER_FLAG_END_OF_STREAM);
        return C.RESULT_BUFFER_READ;
      }
      long bufferedPositionUs = getBufferedPositionUs();
      @ReadDataResult int result = childStream.readData(formatHolder, buffer, readFlags);
      if (lastReportedDiscontinuityUs != C.TIME_UNSET && result != C.RESULT_NOTHING_READ) {
        // We read something, so don't suppress further discontinuities even if they are to the same
        // position as the last one.
        lastReportedDiscontinuityUs = C.TIME_UNSET;
      }
      if (result == C.RESULT_FORMAT_READ) {
        updateDecoderDelayPaddingForClipping(formatHolder, startUs, endUs);
        return C.RESULT_FORMAT_READ;
      }
      if (endUs != C.TIME_END_OF_SOURCE
          && ((result == C.RESULT_BUFFER_READ && buffer.timeUs >= endUs)
              || (result == C.RESULT_NOTHING_READ
                  && bufferedPositionUs == C.TIME_END_OF_SOURCE
                  && !buffer.waitingForKeys))) {
        buffer.clear();
        buffer.setFlags(C.BUFFER_FLAG_END_OF_STREAM);
        sentEos = true;
        return C.RESULT_BUFFER_READ;
      }
      return result;
    }

    @Override
    public int skipData(long positionUs) {
      if (isPendingInitialDiscontinuity()) {
        return C.RESULT_NOTHING_READ;
      }
      return childStream.skipData(positionUs);
    }

    @Override
    public @SampleStream.Flags int getFlags() {
      int flags = childStream.getFlags();
      if (endUs != C.TIME_END_OF_SOURCE) {
        flags |= FLAG_STRICT_DURATION;
      }
      // A non-zero clipping start introduces preroll the wrapped period cannot know about, because
      // sample streams provide buffers starting at a key-frame that may precede the clipping start
      // point. With a zero clipping start the samples delivered are exactly the samples the wrapped
      // period delivers, so its own report is exact and must not be overwritten with the
      // conservative assumption made by the enable-position heuristic.
      if (startUs != 0 && hasPreroll) {
        flags &= ~FLAG_MAYBE_HAS_PREROLL;
        flags |= FLAG_HAS_PREROLL;
      }
      return flags;
    }
  }

  private static void updateDecoderDelayPaddingForClipping(
      FormatHolder formatHolder, long startUs, long endUs) {
    Format format = checkNotNull(formatHolder.format);
    if (format.encoderDelay != 0 || format.encoderPadding != 0) {
      // Clear gapless playback metadata if the start/end points don't match the media.
      int encoderDelay = startUs != 0 ? 0 : format.encoderDelay;
      int encoderPadding = endUs != C.TIME_END_OF_SOURCE ? 0 : format.encoderPadding;
      formatHolder.format =
          format
              .buildUpon()
              .setEncoderDelay(encoderDelay)
              .setEncoderPadding(encoderPadding)
              .build();
    }
  }
}
