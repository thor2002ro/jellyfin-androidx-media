/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.effect;

import static android.os.Build.VERSION.SDK_INT;
import static androidx.media3.common.ColorInfo.isWideColorGamut;
import static androidx.media3.common.video.Frame.USAGE_GPU_COLOR_OUTPUT;
import static androidx.media3.effect.DefaultGlFrameProcessor.BT2020_HLG;
import static androidx.media3.effect.DefaultGlFrameProcessor.BT709_SRGB;
import static androidx.media3.effect.FrameProcessorUtils.createAndBindEglImage;
import static androidx.media3.effect.FrameProcessorUtils.releaseEglImageTexture;
import static androidx.media3.effect.FrameProcessorUtils.runAllAndAccumulateExceptions;
import static androidx.media3.effect.FrameProcessorUtils.validateRgba8888Planes;
import static androidx.media3.effect.FrameProcessorUtils.waitAndCloseFence;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import android.content.Context;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.opengl.EGLDisplay;
import android.opengl.GLES20;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.GlTextureInfo;
import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.ExperimentalApi;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.GlUtil.GlException;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.Size;
import androidx.media3.common.video.AsyncFrame;
import androidx.media3.common.video.FrameWriter;
import androidx.media3.common.video.HardwareBufferFrame;
import androidx.media3.common.video.ImagePlanesFrame;
import androidx.media3.common.video.ImagePlanesFrame.Plane;
import androidx.media3.common.video.SyncFenceWrapper;
import androidx.media3.effect.FrameProcessorUtils.EglImageTextureWrapper;
import com.google.common.collect.ImmutableList;
import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.concurrent.Executor;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;

/**
 * Writes input texture frames to a {@link FrameWriter}.
 *
 * <p>Supports {@link HardwareBufferFrame} and {@link PixelFormat#RGBA_8888}-based {@link
 * ImagePlanesFrame}.
 */
@ExperimentalApi // TODO: b/505721737 Remove once FrameProcessor is production ready.
/* package */ final class FrameWriterGlTextureFrameConsumer implements GlTextureFrameConsumer {

  private static final String TAG = "FrameWriterGlTexCons";
  private static final long OUTPUT_USAGE = USAGE_GPU_COLOR_OUTPUT;

  private final Context context;
  private final FrameWriter frameWriter;
  @Nullable private final HardwareBufferJniWrapper hardwareBufferJniWrapper;

  @Nullable private ColorConversionShaderProgram colorConversionShaderProgram;
  @Nullable private GlTextureInfo intermediateTexture;
  private @MonotonicNonNull ByteBuffer rgbaReadbackBuffer;
  private @MonotonicNonNull EGLDisplay eglDisplay;
  private @MonotonicNonNull Size inputSize;
  private @MonotonicNonNull ColorInfo inputColorInfo;
  private @MonotonicNonNull Format outputFormat;
  private boolean isFrameWriterConfigured;

  FrameWriterGlTextureFrameConsumer(
      Context context,
      FrameWriter frameWriter,
      @Nullable HardwareBufferJniWrapper hardwareBufferJniWrapper) {
    this.context = context;
    this.frameWriter = frameWriter;
    this.hardwareBufferJniWrapper = hardwareBufferJniWrapper;
  }

  /** The method runs on the GL thread. */
  @Override
  public boolean queue(
      GlTextureFrame inputFrame, Executor listenerExecutor, Runnable wakeupListener)
      throws VideoFrameProcessingException {
    if (!isFrameWriterConfigured) {
      outputFormat = establishOutputFormat(inputFrame.format);
      frameWriter.configure(outputFormat, OUTPUT_USAGE);
      isFrameWriterConfigured = true;
    }

    maybeReconfigureShader(inputFrame);

    AsyncFrame asyncFrame = frameWriter.dequeueInputFrame(listenerExecutor, wakeupListener);
    if (asyncFrame == null) {
      return false;
    }
    if (!waitAndCloseFence(asyncFrame)) {
      GLES20.glFinish();
    }

    if (SDK_INT >= 26 && asyncFrame.frame instanceof HardwareBufferFrame) {
      return queueHardwareBufferFrame((HardwareBufferFrame) asyncFrame.frame, inputFrame);
    }
    if (asyncFrame.frame instanceof ImagePlanesFrame) {
      return queueImagePlanesFrame((ImagePlanesFrame) asyncFrame.frame, inputFrame);
    }
    throw new IllegalArgumentException("Unsupported output frame: " + asyncFrame.frame);
  }

  @Override
  public void signalEndOfStream() {
    frameWriter.signalEndOfStream();
  }

  @Override
  public void close() throws VideoFrameProcessingException {
    @Nullable GlTextureInfo intermediateTexture = this.intermediateTexture;
    this.intermediateTexture = null;
    runAllAndAccumulateExceptions(
        this::releaseGlResources,
        () -> {
          if (intermediateTexture != null) {
            intermediateTexture.release();
          }
        });
  }

  /**
   * Binds the output {@link HardwareBuffer} as an {@code EGLImage} and renders straight into it.
   */
  @RequiresApi(26)
  private boolean queueHardwareBufferFrame(
      HardwareBufferFrame outputHardwareBufferFrame, GlTextureFrame inputFrame)
      throws VideoFrameProcessingException {
    HardwareBuffer outputHardwareBuffer = outputHardwareBufferFrame.getHardwareBuffer();
    HardwareBufferJniWrapper hardwareBufferJniWrapper = checkNotNull(this.hardwareBufferJniWrapper);

    @Nullable SyncFenceWrapper glWriteCompleteFence = null;
    @Nullable SyncFenceWrapper glReadCompleteFence = null;
    @Nullable EglImageTextureWrapper eglImageTextureWrapper = null;
    try {
      if (eglDisplay == null) {
        eglDisplay = GlUtil.getDefaultEglDisplay();
      }
      eglImageTextureWrapper =
          createAndBindEglImage(
              eglDisplay,
              outputHardwareBuffer,
              hardwareBufferJniWrapper,
              /* target= */ GLES20.GL_TEXTURE_2D,
              /* writesToBoundImage= */ true);

      drawFrameToFocusedFramebuffer(inputFrame);
      ImmutableList<SyncFenceWrapper> fences = GlUtil.createSyncFences(/* count= */ 2);
      if (fences.size() == 2) {
        glReadCompleteFence = fences.get(0);
        glWriteCompleteFence = fences.get(1);
      }
    } catch (GlException | VideoFrameProcessingException e) {
      if (eglImageTextureWrapper != null) {
        try {
          releaseEglImageTexture(eglImageTextureWrapper, hardwareBufferJniWrapper);
        } catch (GlException exception) {
          Log.w(TAG, "Failed to release EGLImage during error recovery", exception);
        }
      }
      throw VideoFrameProcessingException.from(e);
    }
    outputHardwareBufferFrame =
        outputHardwareBufferFrame
            .buildUpon()
            .setContentTimeUs(inputFrame.presentationTimeUs)
            .build();
    if (glWriteCompleteFence == null || glReadCompleteFence == null) {
      GLES20.glFinish();
    }
    frameWriter.queueInputFrame(outputHardwareBufferFrame, glWriteCompleteFence);
    inputFrame.release(/* releaseFence= */ glReadCompleteFence);
    try {
      releaseEglImageTexture(eglImageTextureWrapper, hardwareBufferJniWrapper);
    } catch (GlException e) {
      throw VideoFrameProcessingException.from(e);
    }
    return true;
  }

  /**
   * Renders to an offscreen framebuffer object and reads the pixels back into the CPU plane of the
   * output {@link ImagePlanesFrame}.
   */
  private boolean queueImagePlanesFrame(
      ImagePlanesFrame outputImagePlanesFrame, GlTextureFrame inputFrame)
      throws VideoFrameProcessingException {
    Format outputFormat = checkNotNull(this.outputFormat);
    validateRgba8888ImagePlanesFrame(outputImagePlanesFrame);
    try {
      if (intermediateTexture == null) {
        // outputFormat is established once on the first frame and never changes.
        intermediateTexture =
            createTextureWithFbo(
                outputFormat.width,
                outputFormat.height,
                /* useHighPrecisionColorComponents= */ false);
      }
      GlUtil.focusFramebufferUsingCurrentContext(
          intermediateTexture.fboId, outputFormat.width, outputFormat.height);
      drawFrameToFocusedFramebuffer(inputFrame);
      readFocusedFramebufferToRgba8888Frame(outputImagePlanesFrame);
    } catch (GlException e) {
      throw VideoFrameProcessingException.from(e);
    }
    // glReadPixels already synchronized all preceding GL commands, so no fences are needed.
    inputFrame.release(/* releaseFence= */ null);
    outputImagePlanesFrame =
        outputImagePlanesFrame.buildUpon().setContentTimeUs(inputFrame.presentationTimeUs).build();
    frameWriter.queueInputFrame(outputImagePlanesFrame, /* writeCompleteFence= */ null);
    return true;
  }

  private void validateRgba8888ImagePlanesFrame(ImagePlanesFrame frame) {
    Format outputFormat = checkNotNull(this.outputFormat);
    Format frameFormat = frame.getFormat();
    checkArgument(
        frameFormat.pixelFormat == PixelFormat.RGBA_8888
            || frameFormat.pixelFormat == Format.NO_VALUE,
        "Unsupported pixel format: %s",
        frameFormat.pixelFormat);
    checkArgument(
        frameFormat.width == outputFormat.width || frameFormat.width == Format.NO_VALUE,
        "Frame width (%s) must match outputFormat width (%s)",
        frameFormat.width,
        outputFormat.width);
    checkArgument(
        frameFormat.height == outputFormat.height || frameFormat.height == Format.NO_VALUE,
        "Frame height (%s) must match outputFormat height (%s)",
        frameFormat.height,
        outputFormat.height);
    validateRgba8888Planes(frame.getPlanes(), outputFormat.width, outputFormat.height);
  }

  private void readFocusedFramebufferToRgba8888Frame(ImagePlanesFrame frame) throws GlException {
    Format outputFormat = checkNotNull(this.outputFormat);
    int width = outputFormat.width;
    int height = outputFormat.height;
    Plane plane = frame.getPlanes().get(0);
    ByteBuffer planeBuffer = plane.getBuffer();
    int rowBytes = width * plane.getPixelStride();
    int rowStride = plane.getRowStride();
    if (rowStride == rowBytes) {
      // TODO(b/531653682): Use OpenGL ES 3.0 PBOs for asynchronous readback.
      GLES20.glReadPixels(
          /* x= */ 0,
          /* y= */ 0,
          width,
          height,
          GLES20.GL_RGBA,
          GLES20.GL_UNSIGNED_BYTE,
          planeBuffer);
      GlUtil.checkGlError();
      return;
    }
    // OpenGL ES 2.0 lacks GL_PACK_ROW_LENGTH, so glReadPixels always outputs tightly packed rows.
    // Read into a tightly packed scratch buffer first, then copy each row into planeBuffer at its
    // rowStride offset. outputFormat is established once on the first frame and never changes.
    // TODO(b/573498289): On OpenGL ES 3.0+, set GL_PACK_ROW_LENGTH to read directly into
    // planeBuffer when rowStride is a multiple of pixelStride.
    if (rgbaReadbackBuffer == null) {
      rgbaReadbackBuffer = ByteBuffer.allocateDirect(rowBytes * height);
    }
    rgbaReadbackBuffer.clear();
    GLES20.glReadPixels(
        /* x= */ 0,
        /* y= */ 0,
        width,
        height,
        GLES20.GL_RGBA,
        GLES20.GL_UNSIGNED_BYTE,
        rgbaReadbackBuffer);
    GlUtil.checkGlError();
    copyRowsToPlane(rgbaReadbackBuffer, plane, rowBytes, height);
  }

  private static void copyRowsToPlane(
      ByteBuffer source, Plane destinationPlane, int rowBytes, int height) {
    ByteBuffer destination = destinationPlane.getBuffer();
    int destinationRowStride = destinationPlane.getRowStride();
    int initialPosition = destination.position();
    for (int row = 0; row < height; row++) {
      source.limit((row + 1) * rowBytes);
      destination.position(initialPosition + row * destinationRowStride);
      destination.put(source);
    }
    destination.position(initialPosition);
  }

  private void drawFrameToFocusedFramebuffer(GlTextureFrame inputFrame)
      throws GlException, VideoFrameProcessingException {
    GlUtil.clearFocusedBuffersOpaque();
    checkNotNull(colorConversionShaderProgram)
        .drawFrame(inputFrame.glTextureInfo.texId, inputFrame.presentationTimeUs);
    GlUtil.checkGlError();
  }

  /** Establishes the output format based on the first frame. */
  private Format establishOutputFormat(Format inputFormat) {
    ColorInfo outputColorInfo = resolveOutputColorInfo(checkNotNull(inputFormat.colorInfo));
    // This only sets the tags of the output format, the pixel values don't change. SDR pixels are
    // sRGB encoded, which is preferred for RGB content throughout Android, even where it's only
    // labeled "RGB". Some encoders don't accept an sRGB tag, so SDR output is tagged with the SDR
    // (BT.709) transfer instead. Encoders output limited range for both SDR and HDR.
    // TODO(b/545572413): Allow converting outputting to other gamut, for example BT.601.
    ColorInfo frameWriterColorInfo =
        isWideColorGamut(outputColorInfo)
            ? outputColorInfo.buildUpon().setColorRange(C.COLOR_RANGE_LIMITED).build()
            : ColorInfo.SDR_BT709_LIMITED;
    int rotationDegrees =
        calculateOutputRotationDegrees(
            inputFormat.buildUpon().setColorInfo(frameWriterColorInfo).build());
    int outputWidth = rotationDegrees == 90 ? inputFormat.height : inputFormat.width;
    int outputHeight = rotationDegrees == 90 ? inputFormat.width : inputFormat.height;
    return updateFormat(
        inputFormat,
        outputWidth,
        outputHeight,
        // Sets the degrees that the player needs to rotate. If we rotated 90 degrees, the player
        // needs to rotate -90 degrees, which is equivalent to rotating it 270 degrees.
        /* rotationDegrees= */ (360 - rotationDegrees) % 360,
        frameWriterColorInfo);
  }

  /** Reconfigures the shader program if the input size or color space changed. */
  private void maybeReconfigureShader(GlTextureFrame inputFrame)
      throws VideoFrameProcessingException {
    Format inputFormat = inputFrame.format;
    // The frames in the GL pipeline should always be in the intended orientation.
    checkArgument(inputFormat.rotationDegrees == 0);
    ColorInfo inputColorInfo = checkNotNull(inputFormat.colorInfo);
    if (inputSize != null
        && inputFormat.width == inputSize.getWidth()
        && inputFormat.height == inputSize.getHeight()
        && Objects.equals(inputColorInfo, this.inputColorInfo)) {
      return;
    }

    releaseGlResources();

    int inputTextureWidth = inputFrame.glTextureInfo.width;
    int inputTextureHeight = inputFrame.glTextureInfo.height;
    ColorInfo outputColorInfo = resolveOutputColorInfo(inputColorInfo);

    // Force physical rotation to match the logical rotation of the established output format.
    // The output format stores the rotation that player applies. We convert it back to the degrees
    // the pipeline needs to rotate.
    int rotationDegrees = (360 - checkNotNull(outputFormat).rotationDegrees) % 360;

    // Flip OpenGL coordinate system back and rotate.
    GlMatrixTransformation flipAndRotate =
        new ScaleAndRotateTransformation.Builder()
            .setScale(/* scaleX= */ 1f, /* scaleY= */ -1f)
            .setRotationDegrees(rotationDegrees)
            .build();
    Presentation presentation =
        Presentation.createForWidthAndHeight(
            outputFormat.width, outputFormat.height, Presentation.LAYOUT_SCALE_TO_FIT);

    Size rotatedSize = flipAndRotate.configure(inputTextureWidth, inputTextureHeight);
    Size unusedSize = presentation.configure(rotatedSize.getWidth(), rotatedSize.getHeight());

    colorConversionShaderProgram =
        new ColorConversionShaderProgram(
            context,
            inputColorInfo,
            outputColorInfo,
            /* transformationMatrices= */ ImmutableList.of(
                flipAndRotate.getGlMatrixArray(/* presentationTimeUs= */ 0),
                presentation.getGlMatrixArray(/* presentationTimeUs= */ 0)));

    inputSize = new Size(inputFormat.width, inputFormat.height);
    this.inputColorInfo = inputColorInfo;
  }

  private void releaseGlResources() throws VideoFrameProcessingException {
    @Nullable
    ColorConversionShaderProgram colorConversionShaderProgram = this.colorConversionShaderProgram;
    this.colorConversionShaderProgram = null;
    if (colorConversionShaderProgram != null) {
      colorConversionShaderProgram.release();
    }
  }

  /** Creates a texture and an FBO for it, deleting the texture if the FBO can't be created. */
  private static GlTextureInfo createTextureWithFbo(
      int width, int height, boolean useHighPrecisionColorComponents)
      throws VideoFrameProcessingException {
    int texId = C.INDEX_UNSET;
    try {
      texId = GlUtil.createTexture(width, height, useHighPrecisionColorComponents);
      return new GlTextureInfo(
          texId, GlUtil.createFboForTexture(texId), /* rboId= */ C.INDEX_UNSET, width, height);
    } catch (GlException e) {
      if (texId != C.INDEX_UNSET) {
        try {
          GlUtil.deleteTexture(texId);
        } catch (GlException deleteException) {
          e.addSuppressed(deleteException);
        }
      }
      throw VideoFrameProcessingException.from(e);
    }
  }

  /**
   * Returns the electrical {@link ColorInfo} that frames arriving in {@code inputColorInfo} are
   * written in.
   *
   * <p>Frames in a linear color space are converted to HLG for BT.2020, and to sRGB for BT.709.
   * Frames that are already electrical, for example because a {@link ColorConversion} was applied,
   * are written unchanged.
   */
  private static ColorInfo resolveOutputColorInfo(ColorInfo inputColorInfo) {
    if (inputColorInfo.colorTransfer != C.COLOR_TRANSFER_LINEAR) {
      return inputColorInfo;
    }
    return isWideColorGamut(inputColorInfo) ? BT2020_HLG : BT709_SRGB;
  }

  private int calculateOutputRotationDegrees(Format format) {
    if (format.width >= format.height) {
      // Input is landscape, no rotation needed.
      return 0;
    }

    if (frameWriter.getInfo().isSupported(format, OUTPUT_USAGE)) {
      // Portrait is supported, no rotation needed.
      return 0;
    }

    // If frameWriter doesn't support portrait, try rotating the input by 90 degrees to swap to
    // landscape dimensions supported by the encoder.
    int rotatedWidth = format.height;
    int rotatedHeight = format.width;
    Format formatRotate90 =
        // Setting rotation degrees to zero because the encoder doesn't rotate the frame and thus
        // the value is irrelevant. Here we use the swapped dimension to check encoder capability.
        updateFormat(
            format,
            rotatedWidth,
            rotatedHeight,
            /* rotationDegrees= */ 0,
            checkNotNull(format.colorInfo));
    if (frameWriter.getInfo().isSupported(formatRotate90, OUTPUT_USAGE)) {
      return 90;
    }

    // Fallback if nothing is supported.
    return 0;
  }

  private static Format updateFormat(
      Format format, int width, int height, int rotationDegrees, ColorInfo colorInfo) {
    return format
        .buildUpon()
        .setWidth(width)
        .setHeight(height)
        .setRotationDegrees(rotationDegrees)
        .setColorInfo(colorInfo)
        .build();
  }

  @Override
  public boolean isOutputFormatSupported(Format format) {
    // TODO(b/545572413): Check for color space support and fallback to SDR if necessary.
    if (!frameWriter.getInfo().isSupported(format, OUTPUT_USAGE)) {
      return false;
    }
    try {
      if (format.colorInfo != null
          && !GlUtil.isColorTransferSupported(format.colorInfo.colorTransfer)) {
        return false;
      }
    } catch (GlException e) {
      return false;
    }
    return true;
  }
}
